namespace SaleManagement.Schemas;

public record PaymentRequest(Guid OrderId);