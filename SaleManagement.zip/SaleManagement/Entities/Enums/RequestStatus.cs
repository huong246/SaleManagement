namespace SaleManagement.Entities.Enums;

public enum RequestStatus
{
    Pending,
    Approved,
    Rejected,
        
}