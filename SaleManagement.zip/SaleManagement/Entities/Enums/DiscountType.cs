namespace SaleManagement.Entities.Enums;

public enum VoucherTarger
{
    Product,
    Shipping,
}

public enum DiscountMethod
{
    Percentage,
    FixedAmount,
}